﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System.Collections.Generic;
using ConsoleApp1.S;



namespace ConsoleApp1
{
    class Program
    {
        static int K = 10;
        static int p = 8;


        //

        static int Ks = 16;
        static int Ps = 16;
        static void Main(string[] args)
        {




            //Console.WriteLine("Enter your key:");

            //string input = Console.ReadLine() ?? string.Empty;

            //if (input.Length != K)
            //{
            //    Console.WriteLine("Invalid key size. Please enter exactly 10 digits.");
            //    return;
            //}

            //int[] key = new int[K];
            //for (int i = 0; i < K; i++)
            //{
            //    if (!int.TryParse(input[i].ToString(), out key[i]))
            //    {
            //        Console.WriteLine($"Invalid element at index {i}. Please enter valid digits.");
            //        return;
            //    }
            //}

            //// Call the SubKeyGeneration method from the Class1 class
            //Class1 class1Instance = new Class1();
            //class1Instance.Permute10(key);
            //class1Instance.Lshift1();
            //class1Instance.Permute8();
            //class1Instance.Lshift2();
            //class1Instance.Permute8();







            ////Output the subkey array
            ////Console.WriteLine("subkey1 {shift 1}:");
            ////for (int i = 0; i < class1Instance.Subkey1.Length; i++)
            ////{
            ////    Console.Write(class1Instance.Subkey1[i] + " ");
            ////}

            ////Console.WriteLine("subkey2 {shift 2}:");
            ////for (int i = 0; i < class1Instance.Subkey2.Length; i++)
            ////{
            ////    Console.Write(class1Instance.Subkey2[i] + " ");
            ////}






            //Console.WriteLine("Enter your plain text:");

            //string text = Console.ReadLine() ?? string.Empty;

            //if (text.Length != p)
            //{
            //    Console.WriteLine("Invalid plain text size. Please enter exactly 8 digits.");
            //    return;
            //}

            //int[] pt = new int[p];
            //for (int i = 0; i < p; i++)
            //{
            //    if (!int.TryParse(text[i].ToString(), out pt[i]))
            //    {
            //        Console.WriteLine($"Invalid element at index {i}. Please enter valid digits.");
            //        return;
            //    }
            //}






            //class1Instance.IP_PlainText(pt);

            ////Console.WriteLine("plain text IPed:");
            ////for (int i = 0; i < class1Instance.PlainTextIP.Length; i++)
            ////{
            ////    Console.Write(class1Instance.PlainTextIP[i] + " ");
            ////}




            //class1Instance.Split_IPText();
            ////Console.WriteLine("L0 :");
            ////for (int i = 0; i < class1Instance.L0.Length; i++)
            ////{
            ////    Console.Write(class1Instance.L0[i] + " ");
            ////}

            ////Console.WriteLine("R1:");
            ////for (int i = 0; i < class1Instance.R1.Length; i++)
            ////{
            ////    Console.Write(class1Instance.R1[i] + " ");
            ////}





            //class1Instance.R0_EP();
            ////Console.WriteLine("R0_Eped:");
            ////for (int i = 0; i < class1Instance.R0_EPed.Length; i++)
            ////{
            ////    Console.Write(class1Instance.R0_EPed[i] + " ");
            ////}




            //class1Instance.XOR_R1();
            ////Console.WriteLine("XOR result with sk1");
            ////for (int i = 0; i < class1Instance.R0_XOR_SK1.Length; i++)
            ////{
            ////    Console.Write(class1Instance.R0_XOR_SK1[i] + " ");
            ////}




            //class1Instance.SBox_0();



            //class1Instance.SBox_1();
            //class1Instance.Permute4();
            //class1Instance.XOR_L_with_F();
            ////Console.WriteLine("dummy_L");
            ////for (int i = 0; i < class1Instance.dummy_L1.Length; i++)
            ////{
            ////    Console.Write(class1Instance.dummy_L1[i] + " ");
            ////}


            //class1Instance.Swap();
            ////Console.WriteLine("Round 1 outputs");
            ////Console.WriteLine("Right");
            ////for (int i = 0; i < class1Instance.R1Copy.Length; i++)
            ////{
            ////    Console.Write(class1Instance.R1Copy[i] + " ");
            ////}
            ////Console.WriteLine("Left");
            ////for (int i = 0; i < class1Instance.dummy_L1.Length; i++)
            ////{
            ////    Console.Write(class1Instance.dummy_L1[i] + " ");
            ////}

            //class1Instance.R1_EP();
            ////Console.WriteLine("Round 2 R eped");
            ////for (int i = 0; i < class1Instance.R1_EPed.Length; i++)
            ////{
            ////    Console.Write(class1Instance.R1_EPed[i] + " ");
            ////}

            //class1Instance.XOR_R1();
            ////Console.WriteLine("XOR result with sk2");
            ////for (int i = 0; i < class1Instance.R1_XOR_SK2.Length; i++)
            ////{
            ////    Console.Write(class1Instance.R1_XOR_SK2[i] + " ");
            ////}



            //class1Instance.SBox_0();
            ////Console.WriteLine("SBox0 in round2 checking flag 5 binary result for 2 is ");
            ////for (int i = 0; i < class1Instance.Temp1.Length; i++)
            ////{
            ////    Console.Write(class1Instance.Temp1[i] + " ");
            ////}




            //class1Instance.SBox_1();
            ////Console.WriteLine("SBox1 in round2 checking flag 6 binary result for 2 is ");
            ////for (int i = 0; i < class1Instance.Temp2.Length; i++)
            ////{
            ////    Console.Write(class1Instance.Temp2[i] + " ");
            ////}



            //class1Instance.Permute4_R2();
            ////Console.WriteLine("P4 for R2 is ");
            ////for (int i = 0; i < class1Instance.Permuted4_SboxR2.Length; i++)
            ////{
            ////    Console.Write(class1Instance.Permuted4_SboxR2[i] + " ");
            ////}



            //class1Instance.XOR_L_with_F();
            ////Console.WriteLine("Pre-cipher array ");
            ////for (int i = 0; i < class1Instance.Pre_cipher.Length; i++)
            ////{
            ////    Console.Write(class1Instance.Pre_cipher[i] + " ");
            ////}
            ////Console.WriteLine("R1Copy array ");
            ////for (int i = 0; i < class1Instance.R1Copy.Length; i++)
            ////{
            ////    Console.Write(class1Instance.R1Copy[i] + " ");
            ////}





            //class1Instance.Swap();
            ////Console.WriteLine("Pre-cipher array after swap2 ");
            ////for (int i = 0; i < class1Instance.Pre_cipher.Length; i++)
            ////{
            ////    Console.Write(class1Instance.Pre_cipher[i] + " ");
            ////}
            ////Console.WriteLine("R1Copy array after swap2 ");
            ////for (int i = 0; i < class1Instance.R1Copy.Length; i++)
            ////{
            ////    Console.Write(class1Instance.R1Copy[i] + " ");
            ////}


            //class1Instance.MergeArrays();


            //class1Instance.IP_Negative();
            //Console.WriteLine("Cipher text is:  ");
            //for (int i = 0; i < class1Instance.Cipher.Length; i++)
            //{
            //    Console.Write(class1Instance.Cipher[i] + " ");
            //}

















            ///////////////S-AES
            ///

            Console.WriteLine("Enter your key for S-AES:");

            string input = Console.ReadLine() ?? string.Empty;

            if (input.Length != Ks)
            {
                Console.WriteLine("Invalid key size. Please enter exactly 16 digits.");
                return;
            }

            int[] key2 = new int[Ks];
            for (int i = 0; i < Ks; i++)
            {
                if (!int.TryParse(input[i].ToString(), out key2[i]))
                {
                    Console.WriteLine($"Invalid element at index {i}. Please enter valid digits.");
                    return;
                }
            }

            
            
            Class2 classInstance2  = new Class2();

            classInstance2.FirstSplit(key2);

            //Console.WriteLine("w0 is:");
            //for (int i = 0; i < classInstance2.w0.Length; i++)
            //{
            //    Console.Write(classInstance2.w0[i] + " ");
            //}


            //Console.WriteLine("w1 is:");
            //for (int i = 0; i < classInstance2.w1.Length; i++)
            //{
            //    Console.Write(classInstance2.w1[i] + " ");
            //}


            classInstance2.RotNib_W2();

            //Console.WriteLine("RotNib for w1 is:");
            //for (int i = 0; i < classInstance2.w1_RotNibbed.Length; i++)
            //{
            //    Console.Write(classInstance2.w1_RotNibbed[i] + " ");
            //}


            classInstance2.Sub_Nib();
            //Console.WriteLine("w1_SubNibbed array:");
            //for (int i = 0; i < classInstance2.w1_SubNibbed.Length; i++)
            //{
            //    Console.Write(classInstance2.w1_SubNibbed[i] + " ");

            //}





            classInstance2.W2_Calc();
            //Console.WriteLine("w2:");
            //for (int i = 0; i < classInstance2.w2.Length; i++)
            //{
            //    Console.Write(classInstance2.w2[i] + " ");

            //}

            classInstance2.W3_Calc();
            //Console.WriteLine("w2:");
            //for (int i = 0; i < classInstance2.w3.Length; i++)
            //{
            //    Console.Write(classInstance2.w3[i] + " ");

            //}

            classInstance2.RotNib_W4();
            //Console.WriteLine("w3 rotnibbed:");
            //for (int i = 0; i < classInstance2.w3_RotNibbed.Length; i++)
            //{
            //    Console.Write(classInstance2.w3_RotNibbed[i] + " ");

            //}

            classInstance2.Sub_Nib();

            

            classInstance2.W4_Calc();


            classInstance2.W5_Calc();


            //Console.WriteLine("w0 is:");
            //for (int i = 0; i < classInstance2.w0.Length; i++)
            //{
            //    Console.Write(classInstance2.w0[i] + " ");
            //}


            //Console.WriteLine("w1 is:");
            //for (int i = 0; i < classInstance2.w1.Length; i++)
            //{
            //    Console.Write(classInstance2.w1[i] + " ");
            //}



            //Console.WriteLine("w2:");
            //for (int i = 0; i < classInstance2.w2.Length; i++)
            //{
            //    Console.Write(classInstance2.w2[i] + " ");

            //}


            //Console.WriteLine("w3:");
            //for (int i = 0; i < classInstance2.w3.Length; i++)
            //{
            //    Console.Write(classInstance2.w3[i] + " ");

            //}


            //Console.WriteLine("w4:");
            //for (int i = 0; i < classInstance2.w4.Length; i++)
            //{
            //    Console.Write(classInstance2.w4[i] + " ");

            //}

            //Console.WriteLine("w5:");
            //for (int i = 0; i < classInstance2.w5.Length; i++)
            //{
            //    Console.Write(classInstance2.w5[i] + " ");

            //}




            classInstance2.Merge();


            //Console.WriteLine("K0:");
            //for (int i = 0; i < classInstance2.K0.Length; i++)
            //{
            //    Console.Write(classInstance2.K0[i] + " ");

            //}

            //Console.WriteLine("K1:");
            //for (int i = 0; i < classInstance2.K1.Length; i++)
            //{
            //    Console.Write(classInstance2.K1[i] + " ");

            //}


            //Console.WriteLine("K2:");
            //for (int i = 0; i < classInstance2.K2.Length; i++)
            //{
            //    Console.Write(classInstance2.K2[i] + " ");

            //}



            Console.WriteLine("Enter your plain text:");

            string text = Console.ReadLine() ?? string.Empty;

            if (text.Length != Ps)
            {
                Console.WriteLine("Invalid plain text size. Please enter exactly 8 digits.");
                return;
            }


            int[] pt2 = new int[Ps];
            for (int i = 0; i < Ps; i++)
            {
                if (!int.TryParse(text[i].ToString(), out pt2[i]))
                {
                    Console.WriteLine($"Invalid element at index {i}. Please enter valid digits.");
                    return;
                }
            }


            classInstance2.RecieveText(pt2);

            //Console.WriteLine("Plain text  = :");
            //for (int i = 0; i < classInstance2.Main_Plain_Text.Length; i++)
            //{
            //    Console.Write(classInstance2.Main_Plain_Text[i] + " ");

            //}
            classInstance2.P_XOR_Kr();

            //Console.WriteLine("Plain text XOR K0 = :");
            //for (int i = 0; i < classInstance2.PL_XOR_Kr.Length; i++)
            //{
            //    Console.Write(classInstance2.PL_XOR_Kr[i] + " ");

            //}



            classInstance2.Sub_Nib16();
            //Console.WriteLine("SubNib the XOR is :");
            //for (int i = 0; i < classInstance2.PL_XOR_Kr_SubNibbed.Length; i++)
            //{
            //    Console.Write(classInstance2.PL_XOR_Kr_SubNibbed[i] + " ");

            //}




            classInstance2.swap();
            //Console.WriteLine("Swapped :");
            //for (int i = 0; i < classInstance2.temp.Length; i++)
            //{
            //    Console.Write(classInstance2.temp[i] + " ");

            //}


            classInstance2.MixColumnA();
            classInstance2.MixColumnB();
            classInstance2.MixColumnC();
            classInstance2.MixColumnD();
            classInstance2.Merge2();
            classInstance2.R1_XOR_K1();
            classInstance2.Sub_Nib16_2();
            classInstance2.swap();
            classInstance2.R2_XOR_K2();
            Console.WriteLine("Cipher :");
            for (int i = 0; i < classInstance2.Cipher.Length; i++)
            {
                Console.Write(classInstance2.Cipher[i] + " ");

            }

        }
    }


}
