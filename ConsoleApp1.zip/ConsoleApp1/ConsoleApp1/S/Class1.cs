﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConsoleApp1.S
{
    public class Class1
    {
        static int K = 10;//64
        static int Y = 4;//28

        int Flag1 = 0;
        int Flag2 = 0;

        //Phase (1) for Sub-Key generation.
        //____________________________________

        

        //public int[] Key { get; set; } = new int[10];//Main input key


        public int[] P10Table { get; set; } = new int[] { 3, 5, 2, 7, 4, 10, 1, 9, 8, 6 };

        public int[] KPermuted { get; set; } = new int[10];//Main key after p-1 permutation

        public int[] KPermutedCopy { get; set; } = new int[10];//Main key after p-1 permutation

        public int[] P8Table { get; set; } = new int[] { 6, 3, 7, 4, 8, 5, 10, 9 };

        public int[] KPermuted2 { get; set; } = new int[8];//after applying second permutation 8 //this our sub key 1

        public int[] Subkey1 { get; set; } = new int[8];//which will have the values of KPermuted2 of shift 1

        public int[] Subkey2 { get; set; } = new int[8];//which will have the values of KPermutedCopy of shift 2



        //Phase (2) Applying 'F' function and getting cipher text.
        //_________________________________________________________

        public int[] IP { get; set; } = new int[] { 2, 6, 3, 1, 4, 8, 5, 7 };//Initial permutation for 8-bit plain text.

        public int[] IP_Negative1 { get; set; } = new int[] { 4,1,3,5,7,2,8,6};

        public int[] EP { get; set; } = new int[] { 4, 1, 2, 3, 2, 3, 4, 1 };

        public int[] P4 { get; set; } = new int[] { 2,4,3,1 };


        public int[,] SBox0 { get; set; } = new int[,]
{
                { 1, 0, 3, 2 },
                { 3, 2, 1, 0 },
                { 0, 2, 1, 3 },
                { 3, 1, 3, 2 } };

        public int[,] SBox1 { get; set; } = new int[,]
{
                { 0, 1, 2, 3 },
                { 2, 0, 1, 3 },
                { 3, 0, 1, 0 },
                { 2, 1, 0, 3 }};


        public int[] PlainTextIP { get; set; } = new int[8] ;//Plain text array after applying IP on recieved plain text

        public int[] L0 { get; set; } = new int[Y];//Left half of plain text IP table

        public int[] R0 { get; set; } = new int[Y];//Right half of plain text after IP table

        public int[] R0_EPed { get; set; } = new int[8];//Array after applying EP table on R0 for 'f' function. (4 -> 8 bits)

        public int[] R0_XOR_SK1 { get; set; } = new int[8];//XOR among R0(EPed) and sk1


        public int[] Temp1 { get; set; } = new int[2];
        public int[] Temp2 { get; set; } = new int[2];



        public int[] SboxR { get; set; } = new int[4];

        public int[] Permuted4_SboxR { get; set; } = new int[4];//Output of F function

        public int[] dummy_L1 { get; set; } = new int[4]; //before swapping with R0


        public int[] L1 { get; set; } = new int[4];

        public int[] R1Copy { get; set; } = new int[4];


       

        //public int[] R1_EPed { get; set; } = new int[8];

        public void Permute10(int [] Key)
        {
            if(Key.Length == K)
            {
                for(int i=0; i<P10Table.Length; i++)
                {
                    //Console.WriteLine(i + " " + P1Table[i]);
                    for (int j = 0; j < Key.Length; j++)
                    {
                        if (P10Table[i] == j+1)
                        {
                            KPermuted[i] = Key[j];
                            
                            //Console.WriteLine(j + " " + Key[j]);
                            break;
                        }
                    }
                }
                
            }
            else
            {
                Console.WriteLine("Please enter a key of the correct size:");
            }

        }




        public void Permute8()
        {
            if(Flag1 == 1) 
            {
                for (int i = 0; i < P8Table.Length; i++)
                {
                    for (int j = 0; j < KPermuted.Length; j++)
                    {
                        if (P8Table[i] == j + 1)
                        {
                            KPermuted2[i] = KPermuted[j];
                            Subkey1[i] = KPermuted2[i];

                            //Console.WriteLine(j + " " + KPermuted[j]);
                            break;
                        }
                    }
                }
                Flag1 = 0;
            }
            if(Flag2 == 1)
            {
                for (int i = 0; i < P8Table.Length; i++)
                {
                    for (int j = 0; j < KPermutedCopy.Length; j++)
                    {
                        if (P8Table[i] == j + 1)
                        {
                            Subkey2[i] = KPermutedCopy[j];
                            //Console.WriteLine(j + " " + KPermuted[j]);
                            break;
                        }
                    }
                }
                Flag2 = 0;

            }

        }



        public void Lshift1()
        {
            //first half
            int[] temp1 = new int[KPermuted.Length / 2];

            Array.Copy(KPermuted, temp1, KPermuted.Length / 2);

            for (int i = 0; i < KPermuted.Length / 2 - 1; i++)
            {
                KPermuted[i] = temp1[i + 1];
            }

            KPermuted[KPermuted.Length / 2 - 1] = temp1[0];


            //second half
            int[] temp2 = new int[KPermuted.Length / 2];

            Array.Copy(KPermuted, KPermuted.Length / 2, temp2, 0, KPermuted.Length / 2);

            for (int i = KPermuted.Length / 2; i < KPermuted.Length - 1; i++)
            {
                KPermuted[i] = temp2[i - KPermuted.Length / 2 + 1];
            }

            KPermuted[KPermuted.Length - 1] = temp2[0];


            Array.Copy(KPermuted, KPermutedCopy, KPermuted.Length);

            Flag1 = 1;
        }



        public void Lshift2()
        {
            //first half
            int[] temp1 = new int[2];

            Array.Copy(KPermutedCopy, temp1, 2);

            for (int i = 0; i < KPermutedCopy.Length / 2 - 2; i++)
            {
                KPermutedCopy[i] = KPermutedCopy[i + 2];
            }

            KPermutedCopy[KPermutedCopy.Length / 2 - 2] = temp1[0];

            KPermutedCopy[KPermutedCopy.Length / 2 - 1] = temp1[1];


            //second half
            int[] temp2 = new int[2];

            Array.Copy(KPermutedCopy, KPermutedCopy.Length / 2, temp2, 0, 2);

            for (int i = KPermutedCopy.Length / 2; i < KPermutedCopy.Length - 2; i++)
            {
                KPermutedCopy[i] = KPermutedCopy[i + 2];
            }

            KPermutedCopy[KPermutedCopy.Length - 2] = temp2[0];

            KPermutedCopy[KPermutedCopy.Length - 1] = temp2[1];

            Flag2 = 1;
        }



        public void IP_PlainText(int[] Plaintext)
        {
            for (int i = 0; i < IP.Length; i++)
            {
                for (int j = 0; j < Plaintext.Length; j++)
                {
                    if (IP[i] == j + 1)
                    {
                        PlainTextIP[i] = Plaintext[j];

                        //Console.WriteLine(IP[i] + " " + PlainTextIP[i]);
                        break;
                    }
                }
            }

        }


        public void Split_IPText()
        {
            for (int i = 0; i < 4; i++)
            {
                L0[i] = PlainTextIP[i];
                //Console.WriteLine(" L0" + L0[i]);
            }

            int w = 0;

            for (int j = 4; j < 8; j++)
            {
                R0[w] = PlainTextIP[j];
                //Console.WriteLine(" R0" + R0[j]);
                w++;
            }
            
            Array.Copy(R0, R1Copy, 4);

        }



        //Rule:
        //_______
        //L(n) = R(n - 1)
        //R(n) = L(n) 'XOR' f(R(n - 1), K(n))

        //We start with this f(R(n - 1), K(n))
        public int Flag4 = 0;

        public void R0_EP()
        {
            for (int i = 0; i < EP.Length; i++)
            {
                for (int j = 0; j < R0.Length; j++)
                {
                    if (EP[i] == j + 1)
                    {
                        R0_EPed[i] = R0[j];

                        //Console.WriteLine(i + " " + R0_EPed[i]);
                        break;
                    }
                }
            }
            Flag4 = 1;
        }



        public int[] XOR_R1()//2 round functions XORing with sk after R0_EP & R1_EP function
        {
            if(Flag4 ==1)
            {
                for (int i = 0; i < 8; i++)
                {
                    if (R0_EPed[i] != Subkey1[i])
                    {
                        R0_XOR_SK1[i] = 1;

                    }
                    else
                    {
                        R0_XOR_SK1[i] = 0;
                    }
                    

                }
                Flag4 = 0;
                return R0_XOR_SK1;
                
                
            }
            else
            {

                if (Flag3 == 1)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        if (R1_EPed[i] != Subkey2[i])
                        {
                            R1_XOR_SK2[i] = 1;

                        }
                        else
                        {
                            R1_XOR_SK2[i] = 0;
                        }


                    }
                    Flag3 = 0;
                    Flag5 = 1;
                    Flag6 = 1;
                    return R1_XOR_SK2;

                }
                else
                {
                    return R1_XOR_SK2;
                    
                }
            }
            
        }


        
        
        public int SBox_0()
        {
            if(Flag5 ==1)
            {
                int[] L = new int[4];



                Array.Copy(R1_XOR_SK2, L, 4);


                int[] Binary_L = new int[4];

                Binary_L[0] = L[0];
                Binary_L[1] = L[L.Length - 1];
                Binary_L[2] = L[1];
                Binary_L[3] = L[2];

                int OuterInDecimal = BinaryToDecimal(new int[] { Binary_L[0], Binary_L[1] });
                //Console.WriteLine($"The decimal value of the first two elements is: {OuterInDecimal}");test passed!

                int InnerInDecimal = BinaryToDecimal(new int[] { Binary_L[2], Binary_L[3] });
                //Console.WriteLine($"The decimal value of the last two elements is: {InnerInDecimal}");test passed!


                int rows = SBox0.GetLength(0);
                int columns = SBox0.GetLength(1);

                int B1 = 0;


                for (int r = 0; r < rows; r++)
                {
                    if (r == OuterInDecimal)
                    {
                        //Console.Write($"B1:{OuterInDecimal} ");
                        for (int c = 0; c < columns; c++)
                        {
                            if (c == InnerInDecimal)
                            {
                                B1 = SBox0[r, c];
                                //Console.Write($"B1:{B1} ");

                                Temp1 = DecimalToBinary(B1);

                            }
                        }
                    }
                }

                Array.Copy(Temp1, 0, SboxR2, 0, Temp1.Length);

                Flag5 = 0;
                return 0;

            }
            else
            {
                int[] L = new int[4];



                Array.Copy(R0_XOR_SK1, L, 4);


                int[] Binary_L = new int[4];

                Binary_L[0] = L[0];
                Binary_L[1] = L[L.Length - 1];
                Binary_L[2] = L[1];
                Binary_L[3] = L[2];

                int OuterInDecimal = BinaryToDecimal(new int[] { Binary_L[0], Binary_L[1] });
                //Console.WriteLine($"The decimal value of the first two elements is: {OuterInDecimal}");

                int InnerInDecimal = BinaryToDecimal(new int[] { Binary_L[2], Binary_L[3] });
                //Console.WriteLine($"The decimal value of the last two elements is: {InnerInDecimal}");


                int rows = SBox0.GetLength(0);
                int columns = SBox0.GetLength(1);

                int B1 = 0;


                for (int r = 0; r < rows; r++)
                {
                    if (r == OuterInDecimal)
                    {
                        //Console.Write($"B1:{OuterInDecimal} ");
                        for (int c = 0; c < columns; c++)
                        {
                            if (c == InnerInDecimal)
                            {
                                B1 = SBox0[r, c];
                                //Console.Write($"B1:{B1} ");

                                Temp1 = DecimalToBinary(B1);

                            }
                        }
                    }
                }

                Array.Copy(Temp1, 0, SboxR, 0, Temp1.Length);

                return 0;

            }
            
        }


        public int SBox_1()
        {
            if (Flag6 == 1)
            {
                int[] R = new int[4];


                Array.Copy(R1_XOR_SK2, 4, R, 0, 4);



                int[] Binary_R = new int[4];

                Binary_R[0] = R[0];//1
                Binary_R[1] = R[R.Length - 1];//1
                Binary_R[2] = R[1];//1
                Binary_R[3] = R[2];//0




                int OuterInDecimal = BinaryToDecimal(new int[] { Binary_R[0], Binary_R[1] });
                //Console.WriteLine($"Outer SBOX_1 is: {OuterInDecimal}");

                int InnerInDecimal = BinaryToDecimal(new int[] { Binary_R[2], Binary_R[3] });
                //Console.WriteLine($"Inner SBOX_1 is : {InnerInDecimal}");


                int rows = SBox1.GetLength(0);
                int columns = SBox1.GetLength(1);

                int B2 = 0;


                for (int r = 0; r < rows; r++)
                {
                    if (r == OuterInDecimal)
                    {
                        //Console.Write($"B1:{OuterInDecimal} ");
                        for (int c = 0; c < columns; c++)
                        {
                            if (c == InnerInDecimal)
                            {
                                B2 = SBox1[r, c];
                                //Console.Write($"B1:{B1} ");

                                Temp2 = DecimalToBinary(B2);


                            }
                        }
                    }
                }


                Array.Copy(Temp2, 0, SboxR2, Temp1.Length, Temp2.Length);

                //for(int i = 0; i<SboxR.Length;i++)
                //{
                //    Console.Write($"SboxR:{SboxR[i]} ");
                //}
                Flag6 = 0;
                return 0;
            }
            else
            {
                int[] R = new int[4];


                Array.Copy(R0_XOR_SK1, 4, R, 0, 4);



                int[] Binary_R = new int[4];

                Binary_R[0] = R[0];//1
                Binary_R[1] = R[R.Length - 1];//1
                Binary_R[2] = R[1];//1
                Binary_R[3] = R[2];//0




                int OuterInDecimal = BinaryToDecimal(new int[] { Binary_R[0], Binary_R[1] });
                //Console.WriteLine($"Outer SBOX_1 is: {OuterInDecimal}");

                int InnerInDecimal = BinaryToDecimal(new int[] { Binary_R[2], Binary_R[3] });
                //Console.WriteLine($"Inner SBOX_1 is : {InnerInDecimal}");


                int rows = SBox1.GetLength(0);
                int columns = SBox1.GetLength(1);

                int B2 = 0;


                for (int r = 0; r < rows; r++)
                {
                    if (r == OuterInDecimal)
                    {
                        //Console.Write($"B1:{OuterInDecimal} ");
                        for (int c = 0; c < columns; c++)
                        {
                            if (c == InnerInDecimal)
                            {
                                B2 = SBox1[r, c];
                                //Console.Write($"B1:{B1} ");

                                Temp2 = DecimalToBinary(B2);


                            }
                        }
                    }
                }


                Array.Copy(Temp2, 0, SboxR, Temp1.Length, Temp2.Length);

                //for(int i = 0; i<SboxR.Length;i++)
                //{
                //    Console.Write($"SboxR:{SboxR[i]} ");
                //}

                return 0;
            }
            
        }


        public static int  BinaryToDecimal(int[] binaryArray)
        {
            int decimalValue = 0;
            int binaryLength = binaryArray.Length;

            for (int i = 0; i < binaryLength; i++)
            {
                int bitValue = binaryArray[binaryLength - 1 - i];
                decimalValue += bitValue * (int)Math.Pow(2, i); // Corrected the calculation
            }

            return decimalValue;
        }


        public static int[] DecimalToBinary(int decimalNumber)
        {
            if (decimalNumber == 0)
            {
                return new int[] { 0,0 }; 
            }

            int[] binaryResult = new int[2]; 
            int index = 0;

            while (decimalNumber > 0)
            {
                int remainder = decimalNumber % 2;
                binaryResult[index++] = remainder;
                decimalNumber /= 2;
            }

            Array.Reverse(binaryResult, 0, index); // Reverse the array to get the correct binary representation
            int[] binaryResultTrimmed = new int[index];
            Array.Copy(binaryResult, binaryResultTrimmed, index);

            return binaryResultTrimmed;
        }

        public void Permute4()
        {
            for (int i = 0; i < P4.Length; i++)
            {
                for (int j = 0; j < SboxR.Length; j++)
                {
                    if (P4[i] == j + 1)
                    {
                        Permuted4_SboxR[i] = SboxR[j];

                        //Console.WriteLine(P4[i] + " " + Permuted4_SboxR[i]);
                        break;
                    }
                }
            }
        }


        public int[] XOR_L_with_F()//L0 XOR Result of F function
        {
            if(Flag7==1)
            {
                for (int i = 0; i < 4; i++)
                {
                    if (dummy_L1[i] == Permuted4_SboxR2[i])
                    {
                        Pre_cipher[i] = 0;

                    }
                    else
                    {
                        Pre_cipher[i] = 1;
                    }

                }
                Flag7 = 0;
                Flag8 = 1;
                return Pre_cipher;

            }
            else
            {
                for (int i = 0; i < 4; i++)
                {
                    if (L0[i] == Permuted4_SboxR[i])
                    {
                        dummy_L1[i] = 0;

                    }
                    else
                    {
                        dummy_L1[i] = 1;
                    }

                }

                return dummy_L1;
            }
            
        }

        public void Swap()
        {
            if(Flag8 == 1)
            {
                for (int i = 0; i < Pre_cipher.Length; i++)
                {
                    int temp = Pre_cipher[i];
                    Pre_cipher[i] = R1Copy[i];
                    R1Copy[i] = temp;
                }
                Flag8 = 0;
            }
            else
            {
                for (int i = 0; i < dummy_L1.Length; i++)
                {
                    int temp = dummy_L1[i];
                    dummy_L1[i] = R1Copy[i];
                    R1Copy[i] = temp;
                }
            }

            

            //for (int i = 0; i < R1Copy.Length; i++)
            //{

            //    Console.Write("R" + R1Copy[i]);
            //}

            //for (int i = 0; i < dummy_L1.Length; i++)
            //{

            //    Console.Write("Dumm" + dummy_L1[i]);
            //}



        }




        //Start of round 2


        public int[] R1_EPed { get; set; } = new int[8];

        public int Flag3 = 0;
        public int Flag5 = 0;
        public int Flag6 = 0;
        public int Flag7 = 0;
        public int Flag8 = 0;

        public int[] R1_XOR_SK2 { get; set; } = new int[8];//XOR among R1(EPed) and sk2

        public int[] SboxR2 { get; set; } = new int[4];

        public int[] Permuted4_SboxR2 { get; set; } = new int[4];//Output of F function

        public int[] Pre_cipher { get; set; } = new int[4];

        public int[] Before_IPNegative1 { get; set; } = new int[8];

        public int[] Cipher { get; set; } = new int[8];


        public int [] R1_EP()
        {
            for (int i = 0; i < EP.Length; i++)
            {
                for (int j = 0; j < R1Copy.Length; j++)
                {
                    if (EP[i] == j + 1)
                    {
                        R1_EPed[i] = R1Copy[j];

                        break;
                    }
                }
            }
            Flag3 = 1;
            return R1_EPed;
            
        }


        public void Permute4_R2()
        {
            for (int i = 0; i < P4.Length; i++)
            {
                for (int j = 0; j < SboxR2.Length; j++)
                {
                    if (P4[i] == j + 1)
                    {
                        Permuted4_SboxR2[i] = SboxR2[j];

                        //Console.WriteLine(P4[i] + " " + Permuted4_SboxR[i]);
                        break;
                    }
                }
            }
            Flag7 = 1;
        }



        public void MergeArrays()
        {
           
            for (int i = 0; i < 4; i++)
            {
                Before_IPNegative1[i] = R1Copy[i];
            }


            for (int i = 0; i < 4; i++)
            {
                Before_IPNegative1[i + 4] = Pre_cipher[i];
            }

        }


        public void IP_Negative()
        {
            for (int i = 0; i < IP_Negative1.Length; i++)
            {
                for (int j = 0; j < Before_IPNegative1.Length; j++)
                {
                    if (IP_Negative1[i] == j + 1)
                    {
                        Cipher[i] = Before_IPNegative1[j];

                        
                        break;
                    }
                }
            }

        }


    }
}
