﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.S
{
    public class Class2
    {//Simplified - AES!
     
        public int[] w0 { get; set; } = new int[8];

        public int[] w1 { get; set; } = new int[8];

        public int[] K0 { get; set; } = new int[16];

        //K0 = w0 , w1
            


        public int[] w2 { get; set; } = new int[8];

        public int[] w3 { get; set; } = new int[8];

        public int[] K1 { get; set; } = new int[16];

        //K1 = w2 , w3



        public int[] w4 { get; set; } = new int[8];

        public int[] w5 { get; set; } = new int[8];

        public int[] K2 { get; set; } = new int[16];

        //K2 = w4 , w5

        public String[] Nibble { get; set; } = new String [] {"0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111",
            "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111" };//16


        public String[] Sub_Nibble { get; set; } = new String[] {"1001", "0100", "1010", "1011", "1101", "0001", "1000", "0101",
            "0110", "0010", "0000", "0011", "1100", "1110", "1111", "0111" };//16


        public int[] const_w2 { get; set; } = new int[] {1,0,0,0,0,0,0,0};

        public int[] const_w4 { get; set; } = new int[] { 0, 0, 1, 1, 0, 0, 0, 0 };

        
        


        //Rules to get w2,w3,w4,w5:
        //___________________________

        //w2 = w0 XOR 10000000 XOR SubNib(RotNib(w1))
        //w3 = w2 XOR w1
        //w4 = w2 XOR 0011 0000 XOR SubNib(RotNib(w3))
        //w5 = w4 XOR w3


        public int K = 16;
        public int F1 = 0;
        public int F2 = 0;
        public int F3 = 0;
        public int F4 = 0;
        public int F5 = 0;
        public int F6 = 0;
        public int F7 = 0;
        public int F8 = 0;
        public int F9 = 0;

        public int[] w1_RotNibbed { get; set; } = new int[8];//w1

        
        public int[] w1_SubNibbed { get; private set; } = new int[8]; // New array to store individual digits


        public int[] w3_RotNibbed { get; set; } = new int[8];//w1


        public int[] w3_SubNibbed { get; private set; } = new int[8]; // New array to store individual digits



        //Start of Sub-Key generation phase
        //

        public void FirstSplit(int[] Key)
        {
            
            if(Key.Length == K) 
            {
                for (int i = 0; i < 8; i++)
                {
                    w0[i] = Key[i];
                    
                }
                F1 = 1;

                int k = 0;
                for (int i = 8; i < 16; i++)
                {
                    w1[k] = Key[i];

                    if(k<16)
                    {
                        k++;
                    }
                }

                for(int i = 0; i < Key.Length; i++)
                {
                    K0[i] = Key[i];//We have K0 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                }

            }

        }



        //Start applying w2 rule = w0 XOR 10000000 XOR SubNib(RotNib(w1))
        //
      

        public int[] RotNib_W2()
        {
            if(F1 ==1)
            {
                for (int i = 0; i < 4; i++)
                {
                    w1_RotNibbed[i] = w1[i + 4];
                    w1_RotNibbed[i + 4] = w1[i];
                }
                
            }

            F1 = 0;
            return w1_RotNibbed;
        }

        
        public int[] Sub_Nib()
        {
            if(F6==1)
            {
                string[] BinaryStrings = new string[2];
                string[] SubNibbing = new string[2];


                string firstHalf = string.Join("", w3_RotNibbed.Take(w3_RotNibbed.Length / 2));
                BinaryStrings[0] = firstHalf;//This new array is of length 2 and for w1 elements.


                string secondHalf = string.Join("", w3_RotNibbed.Skip(w3_RotNibbed.Length / 2));
                BinaryStrings[1] = secondHalf;



                for (int i = 0; i < Nibble.Length; i++)
                {
                    for (int j = 0; j < BinaryStrings.Length; j++)
                    {
                        if (Nibble[i] == BinaryStrings[j])
                        {

                            SubNibbing[j] = Sub_Nibble[i];//Replacement of nibble with sub-nibble values for w1 which is a string array
                        }
                    }
                }



                String combined = string.Join("", SubNibbing); // Combine the binary strings

                for (int i = 0; i < combined.Length; i++)
                {
                    w3_SubNibbed[i] = int.Parse(combined[i].ToString()); // Convert each character to an integer and store in the new array
                }

                
                F6 = 0;
                F7 = 1;
                return w3_SubNibbed;
            }
            
            else
            {
                string[] BinaryStrings = new string[2];
                string[] SubNibbing1 = new string[2];


                string firstHalf = string.Join("", w1_RotNibbed.Take(w1_RotNibbed.Length / 2));
                BinaryStrings[0] = firstHalf;//This new array is of length 2 and for w1 elements.


                string secondHalf = string.Join("", w1_RotNibbed.Skip(w1_RotNibbed.Length / 2));
                BinaryStrings[1] = secondHalf;



                for (int i = 0; i < Nibble.Length; i++)
                {
                    for (int j = 0; j < BinaryStrings.Length; j++)
                    {
                        if (Nibble[i] == BinaryStrings[j])
                        {

                            SubNibbing1[j] = Sub_Nibble[i];//Replacement of nibble with sub-nibble values for w1 which is a string array
                        }
                    }
                }



                String combined = string.Join("", SubNibbing1); // Combine the binary strings

                for (int i = 0; i < combined.Length; i++)
                {
                    w1_SubNibbed[i] = int.Parse(combined[i].ToString()); // Convert each character to an integer and store in the new array
                }

                F2 = 1;
                return w1_SubNibbed;
            }
            

        }



        public int[] W2_Calc()
        {
            int[] temp = new int[8];

            if (F2 == 1)//F2 for w1 sub-nibbing is ready
            {
                for (int i = 0; i < const_w2.Length; i++)
                {
                    temp[i] = const_w2[i] ^ w1_SubNibbed[i];
                }

            }
            F2 = 0;
            F3 = 1;


            if(F3 == 1)//Flag indicates that constant is xored with sub-nibbed w1 is ready to be second xored with w0.
            {
                for (int i = 0; i < w0.Length; i++)
                {
                    w2[i] = w0[i] ^ temp[i];
                }
            }
            F3 = 0;
            F4 = 1;
            return w2;
        }



        //Start applying w3 rule = w2 XOR w1
        //

        public int[] W3_Calc()
        {
            if (F4 == 1)
            {
                for (int i = 0; i < w2.Length; i++)
                {
                    w3[i] = w2[i] ^ w1[i];
                }
            }
            F4 = 0;
            F5 = 1;
            return w3;
        }




        //Start applying w4 rule = w2 XOR 00110000 XOR SubNib(RotNib(w3))
        //

        public int[] RotNib_W4()
        {
            if (F5 == 1)
            {
                for (int i = 0; i < 4; i++)
                {
                    w3_RotNibbed[i] = w3[i + 4];
                    w3_RotNibbed[i + 4] = w3[i];
                }

            }

            F5 = 0;
            F6 = 1;
            return w3_RotNibbed;
        }



        public int[] W4_Calc()
        {

            int[] temp = new int[8];

            if (F7 == 1)//F2 for w1 sub-nibbing is ready
            {
                for (int i = 0; i < const_w4.Length; i++)
                {
                    temp[i] = const_w4[i] ^ w3_SubNibbed[i];
                }

            }
            F7 = 0;
            F8 = 1;


            if (F8 == 1)//Flag indicates that constant is xored with sub-nibbed w1 is ready to be second xored with w0.
            {
                for (int i = 0; i < w2.Length; i++)
                {
                    w4[i] = w2[i] ^ temp[i];
                }
            }
            F8 = 0;
            F9 = 1;
            return w4;
        }


        //Start applying w5 rule = w4 XOR w3
        //
        public int[] W5_Calc()
        {
            if (F9 == 1)
            {
                for (int i = 0; i < w4.Length; i++)
                {
                    w5[i] = w4[i] ^ w3[i];
                }
            }
            F9 = 0;
            return w5;
        }




        //Merging All ws to form array kor each key (K0,K1,K2)
        //


        public int[][] Merge()
        {
            Array.Copy(w2, K1, w2.Length);
            Array.Copy(w3, 0, K1, w2.Length, w3.Length);


            Array.Copy(w4, K2, w4.Length);
            Array.Copy(w5, 0, K2, w4.Length, w5.Length);

            return new int[][] { K1, K2 };
        }



        //End of Sub-Key generation phase
        //__________________________________________________________________________________________________________________




        //Start of encryption phase
        //___________________________

        //Add Round (0) Key
        //

        public int[] Main_Plain_Text { get;set; } = new int[16];

        public int[] PL_XOR_Kr { get; set; } = new int[16];

        public int[] PL_XOR_Kr_SubNibbed { get; set; } = new int[16];

        public String[] temp { get; set; } = new String[4];

        public int[] Swapped_R1 { get; set; } = new int[16];

        public String[] S00 { get; set; } = new String[1];
        public String[] S10 { get; set; } = new String[1];
        public String[] S01 { get; set; } = new String[1];
        public String[] S11 { get; set; } = new String[1];

        public int[] R1_Result_Before_XOR { set; get; } = new int[16];

        public int[] R1_Result { set; get; } = new int[16];
        public int[] Final_R_SubNibbed { set; get; } = new int[16];

        public String[] temp2 { get; set; } = new String[4];

        public int[] Swapped_Final_R { get; set; } = new int[16];
        public int[] Cipher { get; set; } = new int[16];


        String[] Matrix = new String[4] {"1", "4", "4", "1"};

        public String[,] Multiplication_Table { get; set; } = new string[,]
{
            { "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"},
            { "2", "4", "6", "8", "a", "c", "e", "3", "1", "7", "5", "b", "9", "f", "d"},
            { "3", "6", "5", "c", "f", "a", "9", "b", "8", "d", "e", "7", "4", "1", "2"},
            { "4", "8", "c", "3", "7", "b", "f", "6", "2", "e", "a", "5", "1", "d", "9"},
            { "5", "a", "f", "7", "2", "d", "8", "e", "b", "4", "1", "9", "c", "3", "6"},
            { "6", "c", "a", "b", "d", "7", "1", "5", "3", "9", "f", "e", "8", "2", "4"},
            { "7", "e", "9", "f", "8", "1", "6", "d", "a", "3", "4", "2", "5", "c", "b"},
            { "8", "3", "b", "6", "e", "5", "d", "c", "4", "f", "7", "a", "2", "9", "1"},
            { "9", "1", "8", "2", "b", "3", "a", "4", "d", "5", "c", "6", "f", "7", "e"},
            { "a", "7", "d", "e", "4", "9", "3", "f", "5", "8", "2", "1", "b", "6", "c"},
            { "b", "5", "e", "a", "1", "f", "4", "7", "c", "2", "9", "d", "6", "8", "3"},
            { "c", "b", "7", "5", "9", "e", "2", "a", "6", "1", "d", "f", "3", "4", "8"},
            { "d", "9", "4", "1", "c", "8", "5", "2", "f", "b", "6", "3", "e", "a", "7"},
            { "e", "f", "1", "d", "3", "2", "c", "9", "7", "6", "8", "4", "a", "b", "5"},
            { "f", "d", "2", "9", "6", "4", "b", "1", "e", "c", "3", "8", "7", "5", "a"}
        };



        public String[,] Addition_Table { get; set; } = new string[,]
{
            { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"},
            { "1", "0", "3", "2", "5", "4", "7", "6", "9", "8", "b", "a", "d", "c", "f", "e"},
            { "2", "3", "0", "1", "6", "7", "4", "5", "a", "b", "8", "9", "e", "F", "C", "D"},
            { "3", "2", "1", "0", "7", "6", "5", "4", "b", "a", "9", "8", "f", "e", "d", "c"},
            { "4", "5", "6", "7", "0", "1", "2", "3", "c", "d", "e", "f", "8", "9", "a", "b"},
            { "5", "4", "7", "6", "1", "0", "3", "2", "d", "c", "f", "e", "9", "8", "b", "a"},
            { "6", "7", "4", "5", "2", "3", "0", "1", "e", "f", "c", "d", "a", "b", "8", "9"},
            { "7", "6", "5", "4", "3", "2", "1", "f", "f", "e", "d", "c", "b", "a", "9", "8"},
            { "8", "9", "a", "b", "c", "d", "e", "e", "0", "1", "2", "3", "4", "5", "6", "7"},
            { "9", "8", "b", "a", "d", "c", "f", "d", "1", "0", "3", "2", "5", "4", "7", "6"},
            { "a", "b", "8", "9", "e", "f", "c", "e", "2", "3", "0", "1", "6", "7", "4", "5"},
            { "b", "a", "9", "8", "f", "e", "d", "c", "3", "2", "1", "0", "7", "6", "5", "4"},
            { "c", "D", "e", "f", "8", "9", "a", "b", "4", "5", "6", "7", "0", "1", "2", "3"},
            { "d", "C", "f", "e", "9", "8", "b", "a", "5", "4", "7", "6", "1", "0", "3", "2"},
            { "e", "F", "c", "d", "a", "b", "8", "9", "6", "7", "4", "5", "2", "3", "0", "1"},
            { "f", "E", "d", "c", "b", "a", "9", "8", "7", "6", "5", "4", "3", "2", "1", "0"}
        };



        public int P = 16;
        public int F10 = 0;
        public int F11 = 0;
        public int F12 = 0;
        public int F13 = 0;
        public int F14 = 0;
        public int F15 = 0;
        public int F16 = 0;
        public int F17 = 0;
        public int F18 = 0;
        public int F19 = 0;
        public int F20 = 0;
        public int F21 = 0;

        public void RecieveText(int[] pt2)//Just recieving the plain text input and adding it in an array.
        {
            if(pt2.Length== P)
            {
                for (int i = 0; i < 16; i++)
                {
                    Main_Plain_Text[i] = pt2[i];

                }
                F10 = 1;
            }
            
        }



        public int[] P_XOR_Kr()//Plain text XOR K0.
        {
            if(F10 ==1)
            {
                for (int i = 0; i < Main_Plain_Text.Length; i++)
                {
                    PL_XOR_Kr[i] = Main_Plain_Text[i] ^ K0[i];
                }
            }
            F10 = 0;
            F11 = 1;
            return PL_XOR_Kr;
        }


        

        //Round (1)
        //

        public int[] Sub_Nib16()
        {
            
            

            if (F11==1)
            {
                string[] resultArray = new string[4]; // New array of length 4
                string[] BinaryStrings = new string[4];
                string[] Subnibbing = new string[4];

                int nibbleLength = 4;

                for (int i = 0; i < PL_XOR_Kr.Length; i += nibbleLength)
                {
                    string nibbleString = string.Join("", PL_XOR_Kr.Skip(i).Take(nibbleLength));
                    resultArray[i / nibbleLength] = nibbleString;
                }





                for (int i = 0; i < Nibble.Length; i++)
                {
                    for (int j = 0; j < resultArray.Length; j++)
                    {
                        if (Nibble[i] == resultArray[j])
                        {

                            Subnibbing[j] = Sub_Nibble[i];
                        }
                    }
                }




                String combined = string.Join("", Subnibbing); 

                for (int i = 0; i < combined.Length; i++)
                {
                    PL_XOR_Kr_SubNibbed[i] = int.Parse(combined[i].ToString()); 
                }

                
                

            }
            F11 = 0;
            return PL_XOR_Kr_SubNibbed;
        }


        
        public int [] swap()
        {
            if(F20==1)
            {
                //string[] temp = new string[4];
                int nibbleLength = 4;


                for (int i = 0; i < Final_R_SubNibbed.Length; i += nibbleLength)
                {
                    string nibbleString = string.Join("", Final_R_SubNibbed.Skip(i).Take(nibbleLength));
                    temp2[i / nibbleLength] = nibbleString;
                }




                // Swap the second and fourth cells of the temp array
                string tempValue = temp2[1];
                temp2[1] = temp2[3];
                temp2[3] = tempValue;

                String combined = string.Join("", temp2);//Convert string to int

                for (int i = 0; i < combined.Length; i++)
                {
                    Swapped_Final_R[i] = int.Parse(combined[i].ToString());
                }

                F20 = 0;
                //F21 = 1;
                return Swapped_Final_R;
            }
            else
            {
                //string[] temp = new string[4];
                int nibbleLength = 4;


                for (int i = 0; i < PL_XOR_Kr_SubNibbed.Length; i += nibbleLength)
                {
                    string nibbleString = string.Join("", PL_XOR_Kr_SubNibbed.Skip(i).Take(nibbleLength));
                    temp[i / nibbleLength] = nibbleString;
                }




                // Swap the second and fourth cells of the temp array
                string tempValue = temp[1];
                temp[1] = temp[3];
                temp[3] = tempValue;

                String combined = string.Join("", temp);//Convert string to int

                for (int i = 0; i < combined.Length; i++)
                {
                    Swapped_R1[i] = int.Parse(combined[i].ToString());
                }


                return Swapped_R1;
            }
           
        }


        
        
        public void MixColumnA()
        {
            int j0 = 0;
            int j2 = 2;
            
            

            //Strings that hold hex after transformation from binary.
            String Hex1= "";
            String Hex4= "";


            //Strings that hold binary.
            String k1;
            String k2;

            




            int rows = Multiplication_Table.GetLength(0);
            int columns = Multiplication_Table.GetLength(1);



            for (int i=0; i<Matrix.Length/2; i++)//Here, i am at the first row (1 , 4) AKA: First half
            {
                if (Matrix[i] == "1") 
                {
                    k2 = temp[j0];
                    Hex1 = BinaryToHex(k2);
                    F12 = 1;
                    Console.WriteLine(Hex1);// 2 ,(1 x 0010 ) = (1 x 2 )

                }
                else
                {
                    
                    k1 = temp[j2];
                    Hex4 = BinaryToHex(k1);
                    F13 = 1;
                    Console.WriteLine(Hex4);// E, (4 x E )
                }
            }


            

            //Multiplication table

            String[] Hexa_Array = new String[2];
            int H = 0;


            string searchValue3 = Matrix[0]; // M[0] = 1 , The value '1' from Matrix
            string searchValue4 = Hex1;      // The value '2' from Hex1

            string searchValue1 = Matrix[1]; // The value '4' from Matrix
            string searchValue2 = Hex4;      // The value 'E' from Hex4

            


            if (F12 == 1)
            {
                for (int r = 0; r < rows; r++)
                {
                    if (Multiplication_Table[r, 0] == searchValue3)
                    {
                        for (int c = 1; c < columns; c++)
                        {
                            if (Multiplication_Table[0, c] == searchValue4)
                            {
                                Hexa_Array[H] = Multiplication_Table[r, c];
                                H++;
                                break; // Exit the inner loop once the answer is found
                            }
                        }
                        if (H >= Hexa_Array.Length)
                        {
                            break; // Exit the outer loop once the required elements are found
                        }
                    }
                }
            }

            if (F13== 1)
            {
                for (int r = 0; r < rows; r++)
                {
                    if (Multiplication_Table[r, 0] == searchValue1)
                    {
                        for (int c = 1; c < columns; c++)
                        {
                            if (Multiplication_Table[0, c] == searchValue2)
                            {
                                Hexa_Array[H] = Multiplication_Table[r, c];
                                H++;
                                break; // Exit the inner loop once the answer is found
                            }
                        }
                        if (H >= Hexa_Array.Length)
                        {
                            break; // Exit the outer loop once the required elements are found
                        }
                    }
                }
            }

            F12 = 0;
            F13 = 0;


            //Addition table



            int rows2 = Addition_Table.GetLength(0);
            int columns2 = Addition_Table.GetLength(1);
            String Temp = "";


            for (int r = 1; r < rows2; r++)
            {
                if (Addition_Table[r, 0] == Hexa_Array[0]) 
                {
                    for (int c = 1; c < columns2; c++)
                    {
                        if (Addition_Table[0, c] == Hexa_Array[1]) 
                        {
                            Temp = Addition_Table[r, c];
                            S00[0] = HexToBinary(Temp);
                            break; 
                        }
                    }
                    break; 
                }
            }

            
            Console.WriteLine("S00[0]: " + S00[0]);


        }

        public void MixColumnB()
        {
            int j0 = 0;
            int j2 = 2;
            


            //Strings that hold hex after transformation from binary.
            String Hex4 = "";
            String Hex1 = "";


            //Strings that hold binary.
            String k1;
            String k2;






            int rows = Multiplication_Table.GetLength(0);
            int columns = Multiplication_Table.GetLength(1);



            for (int i = 2; i < Matrix.Length; i++)//Here, i am at the first row (4 , 1) AKA: Second half
            {
                if (Matrix[i] == "4")
                {
                    k2 = temp[j0];
                    Hex4 = BinaryToHex(k2);
                    F14 = 1;
                    Console.WriteLine(Hex4);// 2

                }
                else
                {

                    k1 = temp[j2];
                    Hex1 = BinaryToHex(k1);
                    F15 = 1;
                    Console.WriteLine(Hex1);// E
                }
            }




            //Multiplication table

            String[] Hexa_Array = new String[2];
            int H = 0;


            String searchValue1 = Matrix[2];//4
            String searchValue2 = Hex4;//2

            String searchValue3 = Matrix[3];//1
            String searchValue4 = Hex1;//E




            if (F14 == 1)
            {
                for (int r = 0; r < rows; r++)
                {
                    if (Multiplication_Table[r, 0] == searchValue1)
                    {
                        for (int c = 1; c < columns; c++)
                        {
                            if (Multiplication_Table[0, c] == searchValue2)
                            {
                                Hexa_Array[H] = Multiplication_Table[r, c];
                                H++;
                                break; // Exit the inner loop once the answer is found
                            }
                        }
                        if (H >= Hexa_Array.Length)
                        {
                            break; // Exit the outer loop once the required elements are found
                        }
                    }
                }
            }

            if (F15 == 1)
            {
                for (int r = 0; r < rows; r++)
                {
                    if (Multiplication_Table[r, 0] == searchValue3)
                    {
                        for (int c = 1; c < columns; c++)
                        {
                            if (Multiplication_Table[0, c] == searchValue4)
                            {
                                Hexa_Array[H] = Multiplication_Table[r, c];
                                H++;
                                break; // Exit the inner loop once the answer is found
                            }
                        }
                        if (H >= Hexa_Array.Length)
                        {
                            break; // Exit the outer loop once the required elements are found
                        }
                    }
                }
            }

            F14 = 0;
            F15 = 0;


            ////Addition table



            int rows2 = Addition_Table.GetLength(0);
            int columns2 = Addition_Table.GetLength(1);
            String Temp = "";


            for (int r = 1; r < rows2; r++)
            {
                if (Addition_Table[r, 0] == Hexa_Array[0])
                {
                    for (int c = 1; c < columns2; c++)
                    {
                        if (Addition_Table[0, c] == Hexa_Array[1])
                        {
                            Temp = Addition_Table[r, c];
                            //Console.WriteLine("Temp: " + Temp);
                            S10[0] = HexToBinary(Temp);
                           
                            break;
                        }
                    }
                    break;
                }
            }


            Console.WriteLine("S10[0]: " + S10[0]);


        }

        public void MixColumnC()
        {
            int j1 = 1;
            int j3 = 3;



            //Strings that hold hex after transformation from binary.
            String Hex1 = "";
            String Hex4 = "";


            //Strings that hold binary.
            String k1;
            String k2;






            int rows = Multiplication_Table.GetLength(0);
            int columns = Multiplication_Table.GetLength(1);



            for (int i = 0; i < Matrix.Length/2; i++)//Here, i am at the first row (1 , 4) AKA: First half
            {
                if (Matrix[i] == "1")
                {
                    k2 = temp[j1];
                    Hex1 = BinaryToHex(k2);
                    F16 = 1;
                    Console.WriteLine(Hex1);// E

                }
                else
                {

                    k1 = temp[j3];
                    Hex4 = BinaryToHex(k1);
                    F17 = 1;
                    Console.WriteLine(Hex4);// E
                }
            }




            //Multiplication table

            String[] Hexa_Array = new String[2];
            int H = 0;


            String searchValue1 = Matrix[0];//1
            String searchValue2 = Hex1;//E

            String searchValue3 = Matrix[1];//4
            String searchValue4 = Hex4;//E




            if (F16 == 1)
            {
                for (int r = 0; r < rows; r++)
                {
                    if (Multiplication_Table[r, 0] == searchValue1)
                    {
                        for (int c = 1; c < columns; c++)
                        {
                            if (Multiplication_Table[0, c] == searchValue2)
                            {
                                Hexa_Array[H] = Multiplication_Table[r, c];
                                H++;
                                break; // Exit the inner loop once the answer is found
                            }
                        }
                        if (H >= Hexa_Array.Length)
                        {
                            break; // Exit the outer loop once the required elements are found
                        }
                    }
                }
            }

            if (F17 == 1)
            {
                for (int r = 0; r < rows; r++)
                {
                    if (Multiplication_Table[r, 0] == searchValue3)
                    {
                        for (int c = 1; c < columns; c++)
                        {
                            if (Multiplication_Table[0, c] == searchValue4)
                            {
                                Hexa_Array[H] = Multiplication_Table[r, c];
                                H++;
                                break; // Exit the inner loop once the answer is found
                            }
                        }
                        if (H >= Hexa_Array.Length)
                        {
                            break; // Exit the outer loop once the required elements are found
                        }
                    }
                }
            }

            F16 = 0;
            F17 = 0;


            //////Addition table



            int rows2 = Addition_Table.GetLength(0);
            int columns2 = Addition_Table.GetLength(1);
            String Temp = "";


            for (int r = 1; r < rows2; r++)
            {
                if (Addition_Table[r, 0] == Hexa_Array[0])
                {
                    for (int c = 1; c < columns2; c++)
                    {
                        if (Addition_Table[0, c] == Hexa_Array[1])
                        {
                            Temp = Addition_Table[r, c];
                            //Console.WriteLine("Temp: " + Temp);
                            S01[0] = HexToBinary(Temp);
                            break;
                        }
                    }
                    break;
                }
            }


            Console.WriteLine("S01[0]: " + S01[0]);


        }

        public void MixColumnD()
        {
            int j1 = 1;
            int j3 = 3;



            //Strings that hold hex after transformation from binary.
            String Hex4 = "";
            String Hex1 = "";


            //Strings that hold binary.
            String k1;
            String k2;






            int rows = Multiplication_Table.GetLength(0);
            int columns = Multiplication_Table.GetLength(1);



            for (int i = 2; i < Matrix.Length; i++)
            {
                if (Matrix[i] == "4")
                {
                    k2 = temp[j1];
                    Hex4 = BinaryToHex(k2);
                    F18 = 1;
                    Console.WriteLine(Hex4);// E

                }
                else
                {

                    k1 = temp[j3];
                    Hex1 = BinaryToHex(k1);
                    F19 = 1;
                    Console.WriteLine(Hex1);// E
                }
            }




            //Multiplication table

            String[] Hexa_Array = new String[2];
            int H = 0;


            String searchValue1 = Matrix[2];//4
            String searchValue2 = Hex4;//E

            String searchValue3 = Matrix[3];//1
            String searchValue4 = Hex1;//E




            if (F18 == 1)
            {
                for (int r = 0; r < rows; r++)
                {
                    if (Multiplication_Table[r, 0] == searchValue1)
                    {
                        for (int c = 1; c < columns; c++)
                        {
                            if (Multiplication_Table[0, c] == searchValue2)
                            {
                                Hexa_Array[H] = Multiplication_Table[r, c];
                                H++;
                                break; // Exit the inner loop once the answer is found
                            }
                        }
                        if (H >= Hexa_Array.Length)
                        {
                            break; // Exit the outer loop once the required elements are found
                        }
                    }
                }
            }

            if (F19 == 1)
            {
                for (int r = 0; r < rows; r++)
                {
                    if (Multiplication_Table[r, 0] == searchValue3)
                    {
                        for (int c = 1; c < columns; c++)
                        {
                            if (Multiplication_Table[0, c] == searchValue4)
                            {
                                Hexa_Array[H] = Multiplication_Table[r, c];
                                H++;
                                break; // Exit the inner loop once the answer is found
                            }
                        }
                        if (H >= Hexa_Array.Length)
                        {
                            break; // Exit the outer loop once the required elements are found
                        }
                    }
                }
            }

            F16 = 0;
            F17 = 0;


            ////////Addition table



            int rows2 = Addition_Table.GetLength(0);
            int columns2 = Addition_Table.GetLength(1);
            String Temp = "";


            for (int r = 1; r < rows2; r++)
            {
                if (Addition_Table[r, 0] == Hexa_Array[0])
                {
                    for (int c = 1; c < columns2; c++)
                    {
                        if (Addition_Table[0, c] == Hexa_Array[1])
                        {
                            Temp = Addition_Table[r, c];
                            //Console.WriteLine("Temp: " + Temp);
                            S11[0] = HexToBinary(Temp);
                            break;
                        }
                    }
                    break;
                }
            }


            Console.WriteLine("S11[0]: " + S11[0]);


        }

        public int[] Merge2()
        {
            String[] temp = new String[4];
            Array.Copy(S00, 0, temp, 0, S00.Length);
            Array.Copy(S10, 0, temp, S00.Length, S10.Length);
            Array.Copy(S01, 0, temp, S00.Length + S10.Length, S01.Length);
            Array.Copy(S11, 0, temp, S00.Length + S10.Length + S01.Length, S11.Length);

            for (int i = 0; i < temp.Length; i++)
            {
                int binaryValue = Convert.ToInt32(temp[i], 2);
                for (int j = 0; j < 4; j++)
                {
                    R1_Result_Before_XOR[i * 4 + j] = (binaryValue >> (3 - j)) & 1;
                }
            }

            //for (int i = 0; i < R1_Result_Before_XOR.Length; i++)
            //{
            //    Console.Write(R1_Result_Before_XOR[i]);
            //    if (i < R1_Result_Before_XOR.Length - 1)
            //    {
            //        Console.Write(", ");
            //    }
            //}




            return R1_Result_Before_XOR;
        }

        public int[] R1_XOR_K1()
        {
            for (int i = 0; i < R1_Result_Before_XOR.Length; i++)
            {
                R1_Result[i] = R1_Result_Before_XOR[i] ^ K1[i];
                
            }



            //for (int i = 0; i < R1_Result.Length; i++)
            //{
            //    Console.WriteLine("R1_Result[" + i + "]: " + R1_Result[i]);
            //}
            //F20 = 1;
            return R1_Result;
        }


        public int[] Sub_Nib16_2()
        {
            string[] resultArray = new string[4]; // New array of length 4
            string[] BinaryStrings = new string[4];
            string[] Subnibbing = new string[4];

            int nibbleLength = 4;

            for (int i = 0; i < R1_Result.Length; i += nibbleLength)
            {
                string nibbleString = string.Join("", R1_Result.Skip(i).Take(nibbleLength));
                resultArray[i / nibbleLength] = nibbleString;
            }





            for (int i = 0; i < Nibble.Length; i++)
            {
                for (int j = 0; j < resultArray.Length; j++)
                {
                    if (Nibble[i] == resultArray[j])
                    {

                        Subnibbing[j] = Sub_Nibble[i];
                    }
                }
            }




            String combined = string.Join("", Subnibbing);

            for (int i = 0; i < combined.Length; i++)
            {
                Final_R_SubNibbed[i] = int.Parse(combined[i].ToString());
            }


            //for (int i = 0; i < Final_R_SubNibbed.Length; i++)
            //{
            //    Console.WriteLine("Final_R_SubNibbed[" + i + "]: " + Final_R_SubNibbed[i]);
            //}



            F20 = 1;
            return Final_R_SubNibbed;
        }


        public int[] R2_XOR_K2()
        {
            for (int i = 0; i < Swapped_Final_R.Length; i++)
            {
                Cipher[i] = Swapped_Final_R[i] ^ K2[i];

            }


            return Cipher;
        }

        public static string BinaryToHex(string binary)
        {
            if (string.IsNullOrEmpty(binary))
            {
                throw new ArgumentException("Binary string cannot be null or empty.", nameof(binary));
            }

            int length = binary.Length;
            if (length % 4 != 0)
            {
                throw new ArgumentException("Binary string length must be a multiple of 4.", nameof(binary));
            }

            string hex = string.Empty;

            for (int i = 0; i < length; i += 4)
            {
                string nibble = binary.Substring(i, 4);
                int decimalValue = Convert.ToInt32(nibble, 2);
                hex += decimalValue.ToString("x");
            }

            return hex;
        }


        public static string HexToBinary(string hex)
        {
            string binary = string.Join(string.Empty,
                hex.Select(c => Convert.ToString(Convert.ToInt32(c.ToString(), 16), 2).PadLeft(4, '0')));

            return binary;
        }


    }
}
